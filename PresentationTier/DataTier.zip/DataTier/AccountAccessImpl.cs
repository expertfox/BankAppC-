﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DataTier.Implementation
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, UseSynchronizationContext = false)]
    internal class AccountAccessImpl : IAccountAccess
    {
        static BankDB.BankDB bankDB = new BankDB.BankDB();
        BankDB.AccountAccessInterface iAccountAccess = bankDB.GetAccountInterface();

        public uint CreateAccount(uint userID)
        {
            return iAccountAccess.CreateAccount(userID);
        }

        public void Deposit(uint amount)
        {
            iAccountAccess.Deposit(amount);
        }

        public List<uint> GetAccountIDsByUser(uint userID)
        {
            return iAccountAccess.GetAccountIDsByUser(userID);
        }

        public uint GetBalance()
        {
            return iAccountAccess.GetBalance();
        }

        public uint GetOwner()
        {
            return iAccountAccess.GetOwner();
        }

        public void SelectAccount(uint userID)
        {
            iAccountAccess.SelectAccount(userID);
        }

        public void Withdraw(uint amount)
        {
            iAccountAccess.Withdraw(amount);
        }
    }
}
