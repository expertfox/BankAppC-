﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DataTier
{
    [ServiceContract]
    public interface IUserAccess
    {
        [OperationContract]
        void SelectUser(uint userID);

        [OperationContract]
        List<uint> GetUsers();

        [OperationContract]
        uint CreateUser();

        [OperationContract]
        void GetUserName(out string firstName, out string lastName);

        [OperationContract]
        void SetUserName(string fname, string lname);
    }
}

