﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DataTier.Interfaces
{
    [ServiceContract]
    public interface IBankDB
    {
        [OperationContract]
        void SavetoDisk();

        [OperationContract]
        void ProcessAllTransactions();
    }
}

