﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DataTier
{ 
    [ServiceContract]
    public interface ITransactionAccess
    {
        [OperationContract]
        void SelectTransaction(uint transactionID);

        [OperationContract]
        List<uint> Getransactions();

        [OperationContract]
        uint CreateTransaction();

        [OperationContract]
        void GetAmount();

        [OperationContract]
        void GetSenderAccount();

        [OperationContract]
        void GetReceiverAccount();

        [OperationContract]
        void SetAmount(uint amount);

        [OperationContract]
        void SetSender(uint accountID);

        [OperationContract]
        void SetReceiver(uint accountID);
    }
 
}
