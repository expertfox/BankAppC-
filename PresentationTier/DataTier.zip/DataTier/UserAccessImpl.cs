﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DataTier.Implementation
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, UseSynchronizationContext = false)]
    class UserAccessImpl : IUserAccess
    {
        static BankDB.BankDB bankDB = new BankDB.BankDB();
        BankDB.UserAccessInterface iUserAccess = bankDB.GetUserAccess();

        public uint CreateUser()
        {
            return iUserAccess.CreateUser();
        }

        

        public void GetUserName(out string firstName, out string lastName)
        {
            iUserAccess.GetUserName(out firstName, out lastName);
        }

        public List<uint> GetUsers()
        {
            return iUserAccess.GetUsers();
        }

        public void SelectUser(uint userID)
        {
            iUserAccess.SelectUser(userID);
        }

        public void SetUserName(string fname, string lname)
        {
            iUserAccess.SetUserName(fname, lname);
        }
    }
}
