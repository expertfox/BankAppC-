﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DataTier.Implementation
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, UseSynchronizationContext = false)]
    class TransactionAccessImpl : ITransactionAccess
    {
        static BankDB.BankDB bankDB = new BankDB.BankDB();
        BankDB.TransactionAccessInterface iTransactionAccess = bankDB.GetTransactionInterface();

        public uint CreateTransaction()
        {
            return iTransactionAccess.CreateTransaction();
        }

        public void GetAmount()
        {
            iTransactionAccess.GetAmount();
        }

        public List<uint> Getransactions()
        {
            return iTransactionAccess.GetTransactions();
        }

        public void GetReceiverAccount()
        {
            iTransactionAccess.GetRecvrAcct();
        }

        public void GetSenderAccount()
        {
            iTransactionAccess.GetSendrAcct();
        }

        public void SelectTransaction(uint transactionID)
        {
            iTransactionAccess.SelectTransaction(transactionID);
        }

        public void SetAmount(uint amount)
        {
            iTransactionAccess.SetAmount(amount);
        }

        public void SetReceiver(uint accountID)
        {
            iTransactionAccess.SetRecvr(accountID);
        }

        public void SetSender(uint accountID)
        {
            iTransactionAccess.SetSendr(accountID);
        }
    }
}
