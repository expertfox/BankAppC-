﻿using DataTier.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DataTier.Implementation
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, UseSynchronizationContext = false)]
    class BankDBImpl : IBankDB
    {
        static BankDB.BankDB bankDB = new BankDB.BankDB();
        public void ProcessAllTransactions()
        {
            bankDB.SaveToDisk();
        }

        public void SavetoDisk()
        {
            bankDB.ProcessAllTransactions();
        }
    }
}
